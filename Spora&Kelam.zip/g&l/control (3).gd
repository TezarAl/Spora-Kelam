extends Control
# "Spora & Kelam" - tahap 4: mekanik Kelam (cahaya), memasak sup, dan dukungan aset.
# Tempel seluruh isi file ini ke control.gd.
#
# ASET OPSIONAL (kalau file tidak ada, game memakai gambar buatan kode):
#   res://assets/enemies/enemy_0.png ... enemy_4.png   (musuh lantai 1-5, PNG transparan)
#   res://assets/backgrounds/floor_0.png ... floor_4.png (latar lantai 1-5, ukuran 1152x648)
#   res://assets/cards/<nama kartu huruf kecil>.png    (ikon kartu: tebas, tusuk, bakar, santap, nyala,
#                                                       intip, cari, bekal, asah, obor)
#   res://assets/audio/music.ogg                       (musik latar, otomatis loop)
#   res://assets/audio/hit.wav, eat.wav, kelam.wav     (efek suara; boleh .ogg/.mp3)

# ---------- Data kartu tempur ----------
const CARD_DB := {
	"Tebas":  {"cost": 1, "damage": 6,  "heal": 0, "burn": 0, "light": 0},
	"Tusuk":  {"cost": 2, "damage": 12, "heal": 0, "burn": 0, "light": 0},
	"Bakar":  {"cost": 1, "damage": 4,  "heal": 0, "burn": 3, "light": 0},
	"Santap": {"cost": 1, "damage": 0,  "heal": 5, "burn": 0, "light": 0},
	"Nyala":  {"cost": 1, "damage": 0,  "heal": 0, "burn": 0, "light": 1},
}
const START_DECK := ["Tebas", "Tebas", "Tebas", "Tusuk", "Bakar", "Bakar", "Santap", "Santap", "Nyala"]

# ---------- Data kartu eksplorasi ----------
const EXPLORE_DB := {
	"Intip": {"text": "Buka 1 pintu\nyang tersembunyi"},
	"Cari":  {"text": "Dapat 1 kartu\ntempur acak"},
	"Bekal": {"text": "Pulih 4 HP"},
	"Asah":  {"text": "Kartu serang acak\npermanen +2"},
	"Obor":  {"text": "Cahaya +2"},
}
const EXPLORE_DECK := ["Intip", "Intip", "Intip", "Cari", "Cari", "Bekal", "Asah", "Asah", "Obor", "Obor"]
const EXPLORE_HAND := 3
const EXPLORE_ENERGY := 2

# ---------- Data pintu ----------
const DOOR_NAMES := {
	"musuh": "Ruang Jamur", "api": "Api Unggun", "harta": "Peti Harta",
	"jebakan": "Jebakan", "boss": "Jantung Kelam",
}
const DOOR_INFO := {
	"musuh": "Bertarung", "api": "Pulih + masak sup", "harta": "Dapat 1 kartu",
	"jebakan": "Kena damage", "boss": "Pertarungan akhir",
}
const DOOR_COLORS := {
	"musuh": Color(0.8, 0.25, 0.25), "api": Color(0.95, 0.55, 0.15),
	"harta": Color(0.9, 0.8, 0.25), "jebakan": Color(0.6, 0.3, 0.8),
	"boss": Color(0.7, 0.1, 0.3),
}
const CAMPFIRE_HEAL := 12
const TRAP_DAMAGE := 6

# ---------- Kelam & sup ----------
const MAX_LIGHT := 4        # cahaya maksimum
const KELAM_DAMAGE := 3     # damage per giliran kalau cahaya = 0
const MAX_POT := 3          # jamur maksimum di panci
const SOUP_HEAL := 8        # HP pulih per jamur saat sup dimasak
const SOUP_MAXHP := 2       # HP maksimum permanen per jamur

# Data tiap lantai. Ubah hp/dmg di sini untuk mengatur kesulitan.
const FLOORS := [
	{"name": "Jamur Kecil", "hp": 20, "dmg": 4, "cap": Color(0.85, 0.2, 0.25), "scale": 0.9,
		"tint": Color(0.24, 0.18, 0.15), "intro": "Lantai 1 - Lorong Lembap. Bau tanah basah dan spora."},
	{"name": "Jamur Beracun", "hp": 28, "dmg": 5, "cap": Color(0.55, 0.3, 0.75), "scale": 1.0,
		"tint": Color(0.2, 0.17, 0.25), "intro": "Lantai 2 - Gua Berlendir. Dindingnya berdenyut pelan."},
	{"name": "Jamur Raksasa", "hp": 36, "dmg": 6, "cap": Color(0.9, 0.55, 0.15), "scale": 1.15,
		"tint": Color(0.15, 0.22, 0.17), "intro": "Lantai 3 - Taman Spora. Sesuatu yang besar mendengkur di sana."},
	{"name": "Jamur Bayangan", "hp": 44, "dmg": 7, "cap": Color(0.2, 0.3, 0.6), "scale": 1.1,
		"tint": Color(0.12, 0.14, 0.2), "intro": "Lantai 4 - Lorong Gelap. Obor di dinding mulai padam."},
	{"name": "Jantung Kelam", "hp": 55, "dmg": 8, "cap": Color(0.25, 0.12, 0.3), "scale": 1.3,
		"tint": Color(0.1, 0.08, 0.12), "intro": "Lantai 5 - Jantung Kelam. Ia menatapmu balik."},
]

# Pola aksi tiap musuh (diulang berurutan). Aksi: serang, berat, racun, gelap, pulih.
const PATTERNS := [
	["serang", "serang", "berat"],
	["serang", "racun", "serang", "racun"],
	["serang", "serang", "berat", "pulih"],
	["gelap", "serang", "gelap", "berat"],
	["serang", "racun", "gelap", "berat", "pulih"],
]

const STORY_INTRO := [
	"Desa Lumut dulu hidup dari hutan jamur di bawah tanah. Sampai suatu malam, cahaya di lorong-lorongnya padam satu per satu.",
	"Kegelapan itu disebut Kelam. Ia merayap, dan jamur yang disentuhnya berubah menjadi buas dan kelaparan.",
	"Kamu, koki terakhir di desa, hanya punya pisau, panci, dan satu kebiasaan aneh: apa pun yang menyerangmu, kamu masak.",
	"Turunlah ke dalam gua. Jaga cahayamu tetap menyala, kalahkan jamur, santap mereka, dan temukan Jantung Kelam sebelum desa ikut padam.",
]
const STORY_ENDING := [
	"Jantung Kelam berhenti berdenyut. Satu per satu obor di lorong menyala kembali.",
	"Kamu naik ke permukaan dengan perut kenyang dan panci penuh. Desa Lumut punya makan malam untuk setahun.",
	"TAMAT",
]

const HAND_SIZE := 4
const MAX_ENERGY := 3
const EAT_HEAL := 8
const SAVE_PATH := "user://spora_kelam_save.json"


# Latar lorong first-person (kode) atau gambar dari assets/backgrounds
class Backdrop extends Control:
	var tint := Color(0.24, 0.18, 0.15)
	var tex: Texture2D = null
	var gloom := 0.0

	func _draw() -> void:
		var w := size.x
		var h := size.y
		if tex:
			draw_texture_rect(tex, Rect2(Vector2.ZERO, size), false)
		else:
			var cx := w * 0.5
			var cy := h * 0.40
			var far_tl := Vector2(cx - w * 0.28, cy - h * 0.30)
			var far_br := Vector2(cx + w * 0.28, cy + h * 0.30)
			draw_rect(Rect2(0, 0, w, h), tint.darkened(0.6))
			draw_colored_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(far_br.x, far_tl.y), far_tl]), tint.darkened(0.5))
			draw_colored_polygon(PackedVector2Array([Vector2(0, h), Vector2(w, h), far_br, Vector2(far_tl.x, far_br.y)]), tint.darkened(0.3))
			draw_colored_polygon(PackedVector2Array([Vector2(0, 0), far_tl, Vector2(far_tl.x, far_br.y), Vector2(0, h)]), tint)
			draw_colored_polygon(PackedVector2Array([Vector2(w, 0), Vector2(w, h), far_br, Vector2(far_br.x, far_tl.y)]), tint.darkened(0.15))
			draw_rect(Rect2(far_tl, far_br - far_tl), tint.darkened(0.75))
			for i in range(1, 5):
				var t := i * 0.18
				var a := Vector2(0, 0).lerp(far_tl, t)
				var b := Vector2(w, h).lerp(far_br, t)
				draw_rect(Rect2(a, b - a), tint.lightened(0.15), false, 2.0)
		draw_rect(Rect2(0, h * 0.68, w, h * 0.32), Color(0, 0, 0, 0.4))
		# makin sedikit cahaya, makin gelap
		if gloom > 0.0:
			draw_rect(Rect2(0, 0, w, h), Color(0, 0, 0, gloom * 0.5))


# Jamur: gambar dari assets/enemies atau gambar buatan kode, bergoyang pelan
class MushroomView extends Control:
	var cap_color := Color(0.85, 0.2, 0.25)
	var burning := false
	var s := 1.0
	var time := 0.0
	var tex: Texture2D = null

	func _process(delta: float) -> void:
		time += delta
		queue_redraw()

	func _draw() -> void:
		var origin := Vector2(size.x / 2.0, size.y / 2.0 + 20.0 + sin(time * 2.0) * 4.0)
		draw_set_transform(origin, 0.0, Vector2(s, s))
		var base := Vector2.ZERO
		var flame_y := -70.0
		if tex:
			var ts := tex.get_size()
			var th := 200.0
			var tw := th * ts.x / ts.y
			draw_texture_rect(tex, Rect2(Vector2(-tw / 2.0, -110.0), Vector2(tw, th)), false)
			flame_y = -105.0
		else:
			draw_rect(Rect2(base.x - 28, base.y, 56, 70), Color(0.95, 0.9, 0.78))
			draw_circle(base + Vector2(-11, 25), 5, Color.BLACK)
			draw_circle(base + Vector2(11, 25), 5, Color.BLACK)
			var pts := PackedVector2Array()
			for i in range(21):
				var a := PI + PI * i / 20.0
				pts.append(base + Vector2(cos(a) * 75.0, sin(a) * 65.0))
			draw_colored_polygon(pts, cap_color)
			draw_circle(base + Vector2(-35, -30), 9, Color(1, 1, 1, 0.85))
			draw_circle(base + Vector2(10, -45), 11, Color(1, 1, 1, 0.85))
			draw_circle(base + Vector2(40, -20), 7, Color(1, 1, 1, 0.85))
		if burning:
			draw_circle(base + Vector2(-25, flame_y), 12, Color(1, 0.55, 0.1))
			draw_circle(base + Vector2(15, flame_y - 5), 15, Color(1, 0.4, 0.0))
			draw_circle(base + Vector2(40, flame_y + 15), 10, Color(1, 0.8, 0.2))


# ---------- State ----------
var player_hp := 30
var player_max := 30
var energy := MAX_ENERGY
var light := 3
var pot: Array = []

var floor_i := 0
var enemy_name := ""
var enemy_hp := 0
var enemy_max := 0
var enemy_dmg := 0
var enemy_burn := 0
var enemy_turn := 0
var enemy_pattern: Array = []
var player_poison := 0

var deck: Array = []
var hand: Array = []
var discard: Array = []
var card_bonus := {}

var explore_deck: Array = []
var explore_hand: Array = []
var explore_discard: Array = []
var explore_energy := 0
var doors: Array = []
var map_msg := ""

var battle_over := false
var game_over := false

var tex_cache := {}
var music_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer

# node UI
var backdrop: Backdrop
var battle_root: VBoxContainer
var info_label: Label
var player_bar: ProgressBar
var mushroom: MushroomView
var enemy_bar: ProgressBar
var log_label: Label
var hand_box: HBoxContainer
var end_btn: Button
var action_btn: Button
var pot_btn: Button
var hit_tween: Tween

var map_panel: Control
var map_title: Label
var map_path: Label
var map_log: Label
var explore_label: Label
var explore_box: HBoxContainer
var door_box: HBoxContainer

var story_panel: ColorRect
var story_label: Label
var story_btn: Button
var story_tween: Tween
var story_pages: Array = []
var story_i := 0
var story_final_text := ""
var story_done: Callable

var menu_panel: ColorRect
var continue_btn: Button
var pause_btn: Button
var pause_panel: ColorRect


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	randomize()
	_build_ui()
	_build_map_panel()
	_build_story_panel()
	_build_pause_ui()
	_build_menu_panel()
	_setup_audio()
	deck = START_DECK.duplicate()
	deck.shuffle()
	explore_deck = EXPLORE_DECK.duplicate()
	explore_deck.shuffle()
	story_panel.visible = false
	continue_btn.disabled = not FileAccess.file_exists(SAVE_PATH)


func _begin_game() -> void:
	story_panel.visible = false
	floor_i = 0
	light = 3
	map_msg = "Kamu tiba di mulut gua. Pakai kartu eksplorasi untuk mengintip pintu. Jaga cahayamu: kalau padam, Kelam akan melukaimu."
	_enter_map(false)


# ---------- Aset & audio (semua opsional) ----------

func _tex(path: String) -> Texture2D:
	if tex_cache.has(path):
		return tex_cache[path]
	var t: Texture2D = null
	if ResourceLoader.exists(path):
		t = load(path)
	tex_cache[path] = t
	return t


func _load_audio(base: String) -> AudioStream:
	for ext in ["ogg", "wav", "mp3"]:
		var p := "res://assets/audio/%s.%s" % [base, ext]
		if ResourceLoader.exists(p):
			return load(p)
	return null


func _setup_audio() -> void:
	music_player = AudioStreamPlayer.new()
	sfx_player = AudioStreamPlayer.new()
	add_child(music_player)
	add_child(sfx_player)
	var m := _load_audio("music")
	if m:
		if m is AudioStreamOggVorbis or m is AudioStreamMP3:
			m.set("loop", true)
		music_player.stream = m
		music_player.play()


func _play_sfx(base: String) -> void:
	var s := _load_audio(base)
	if s:
		sfx_player.stream = s
		sfx_player.play()


func _set_icon(b: Button, base_name: String) -> void:
	var icon := _tex("res://assets/cards/%s.png" % base_name.to_lower())
	if icon == null:
		return
	b.icon = icon
	b.expand_icon = true
	b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
	b.add_theme_constant_override("icon_max_width", 48)
	b.custom_minimum_size = Vector2(b.custom_minimum_size.x, 140)


func _apply_floor_visuals(idx: int) -> void:
	var data: Dictionary = FLOORS[idx]
	backdrop.tint = data.tint
	backdrop.tex = _tex("res://assets/backgrounds/floor_%d.png" % idx)
	_update_gloom()


func _update_gloom() -> void:
	backdrop.gloom = 1.0 - float(light) / MAX_LIGHT
	backdrop.queue_redraw()


# ---------- Membangun UI ----------

func _make_bar(fill: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(300, 16)
	bar.show_percentage = false
	bar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.1, 0.08, 0.1)
	bg.set_corner_radius_all(4)
	var fg := StyleBoxFlat.new()
	fg.bg_color = fill
	fg.set_corner_radius_all(4)
	bar.add_theme_stylebox_override("background", bg)
	bar.add_theme_stylebox_override("fill", fg)
	return bar


func _make_label(font_size: int, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	return l


func _style_button(b: Button, accent: Color) -> void:
	for state in ["normal", "hover", "pressed", "disabled"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.13, 0.1, 0.12)
		sb.border_color = accent
		if state == "hover":
			sb.bg_color = Color(0.22, 0.16, 0.18)
		if state == "disabled":
			sb.bg_color = Color(0.08, 0.07, 0.08)
			sb.border_color = Color(0.3, 0.3, 0.3)
		sb.set_border_width_all(3)
		sb.set_corner_radius_all(8)
		b.add_theme_stylebox_override(state, sb)


func _build_ui() -> void:
	backdrop = Backdrop.new()
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(backdrop)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	battle_root = VBoxContainer.new()
	battle_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	battle_root.offset_left = 20
	battle_root.offset_top = 16
	battle_root.offset_right = -20
	battle_root.offset_bottom = -16
	battle_root.add_theme_constant_override("separation", 8)
	battle_root.visible = false
	add_child(battle_root)

	info_label = _make_label(20)
	battle_root.add_child(info_label)

	player_bar = _make_bar(Color(0.3, 0.75, 0.35))
	battle_root.add_child(player_bar)

	mushroom = MushroomView.new()
	mushroom.custom_minimum_size = Vector2(260, 230)
	mushroom.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	mushroom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	battle_root.add_child(mushroom)

	enemy_bar = _make_bar(Color(0.8, 0.2, 0.2))
	battle_root.add_child(enemy_bar)

	log_label = _make_label(16, Color(1, 0.93, 0.75))
	log_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	log_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	battle_root.add_child(log_label)

	hand_box = HBoxContainer.new()
	hand_box.alignment = BoxContainer.ALIGNMENT_CENTER
	hand_box.add_theme_constant_override("separation", 12)
	battle_root.add_child(hand_box)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	battle_root.add_child(row)

	end_btn = Button.new()
	end_btn.text = "Akhiri Giliran"
	end_btn.pressed.connect(_end_turn)
	row.add_child(end_btn)

	action_btn = Button.new()
	action_btn.pressed.connect(_on_action_pressed)
	action_btn.visible = false
	row.add_child(action_btn)

	pot_btn = Button.new()
	pot_btn.pressed.connect(_on_pot_pressed)
	pot_btn.visible = false
	row.add_child(pot_btn)


func _build_map_panel() -> void:
	map_panel = Control.new()
	map_panel.visible = false
	add_child(map_panel)
	map_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.45)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	map_panel.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.offset_left = 20
	box.offset_top = 16
	box.offset_right = -20
	box.offset_bottom = -16
	box.add_theme_constant_override("separation", 10)
	map_panel.add_child(box)

	map_title = _make_label(26, Color(0.95, 0.55, 0.15))
	box.add_child(map_title)

	map_path = _make_label(20)
	box.add_child(map_path)

	map_log = _make_label(18, Color(1, 0.93, 0.75))
	map_log.size_flags_vertical = Control.SIZE_EXPAND_FILL
	map_log.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	map_log.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(map_log)

	explore_label = _make_label(18, Color(0.5, 0.75, 1.0))
	box.add_child(explore_label)

	explore_box = HBoxContainer.new()
	explore_box.alignment = BoxContainer.ALIGNMENT_CENTER
	explore_box.add_theme_constant_override("separation", 12)
	box.add_child(explore_box)

	var door_label := _make_label(18)
	door_label.text = "Pilih pintu:"
	box.add_child(door_label)

	door_box = HBoxContainer.new()
	door_box.alignment = BoxContainer.ALIGNMENT_CENTER
	door_box.add_theme_constant_override("separation", 12)
	box.add_child(door_box)


func _build_story_panel() -> void:
	story_panel = ColorRect.new()
	story_panel.color = Color(0.04, 0.03, 0.05)
	add_child(story_panel)
	story_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	story_panel.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 30)
	center.add_child(box)

	var title := _make_label(44, Color(0.95, 0.55, 0.15))
	title.text = "SPORA & KELAM"
	box.add_child(title)

	story_label = _make_label(24)
	story_label.custom_minimum_size = Vector2(700, 140)
	story_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(story_label)

	story_btn = Button.new()
	story_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	story_btn.pressed.connect(_story_next)
	box.add_child(story_btn)


# ---------- Cerita ----------

func _open_story(pages: Array, final_text: String, on_done: Callable) -> void:
	story_pages = pages
	story_i = 0
	story_final_text = final_text
	story_done = on_done
	pause_btn.visible = false
	pause_panel.visible = false
	story_panel.visible = true
	_show_page()


func _show_page() -> void:
	var text: String = story_pages[story_i]
	story_label.text = text
	story_label.visible_ratio = 0.0
	if story_tween:
		story_tween.kill()
	story_tween = create_tween()
	story_tween.tween_property(story_label, "visible_ratio", 1.0, text.length() * 0.03)
	if story_i == story_pages.size() - 1:
		story_btn.text = story_final_text
	else:
		story_btn.text = "Lanjut >"


func _story_next() -> void:
	if story_label.visible_ratio < 1.0:
		if story_tween:
			story_tween.kill()
		story_label.visible_ratio = 1.0
		return
	if story_i < story_pages.size() - 1:
		story_i += 1
		_show_page()
	else:
		story_done.call()


func _reload() -> void:
	get_tree().reload_current_scene()


func _show_ending() -> void:
	_clear_save()
	_open_story(STORY_ENDING, "Main Lagi", _reload)


# ---------- PETA / EXPLORE DECK ----------

func _make_doors() -> Array:
	if floor_i >= FLOORS.size() - 1:
		return [{"type": "boss", "revealed": true}]
	var pool := ["musuh", "musuh", "musuh", "api", "harta", "harta", "jebakan", "jebakan"]
	var result: Array = []
	for i in 3:
		result.append({"type": pool.pick_random(), "revealed": false})
	var has_enemy := false
	for d in result:
		if d["type"] == "musuh":
			has_enemy = true
	if not has_enemy:
		result[randi() % 3]["type"] = "musuh"
	return result


func _draw_explore() -> void:
	if explore_deck.is_empty():
		explore_deck = explore_discard.duplicate()
		explore_discard.clear()
		explore_deck.shuffle()
	if explore_deck.is_empty():
		return
	explore_hand.append(explore_deck.pop_back())


func _enter_map(drain: bool = true) -> void:
	battle_root.visible = false
	map_panel.visible = true
	if drain:
		light = max(0, light - 1)
		if light <= 0:
			map_msg += "\nCahaya padam! Kelam akan menggerogotimu saat bertarung."
		elif light == 1:
			map_msg += "\nCahayamu hampir padam."
	explore_energy = EXPLORE_ENERGY
	explore_discard.append_array(explore_hand)
	explore_hand.clear()
	for i in EXPLORE_HAND:
		_draw_explore()
	doors = _make_doors()
	_show_map()


func _show_map() -> void:
	battle_root.visible = false
	map_panel.visible = true
	pause_btn.visible = true
	_apply_floor_visuals(floor_i)
	_refresh_map()


func _refresh_map() -> void:
	_update_gloom()
	map_title.text = "Lantai %d/%d - Pilih pintu" % [floor_i + 1, FLOORS.size()]

	var parts: Array = []
	for i in FLOORS.size():
		var label := str(i + 1)
		if i == FLOORS.size() - 1:
			label = "BOSS"
		if i < floor_i:
			parts.append("[x]")
		elif i == floor_i:
			parts.append("[> %s <]" % label)
		else:
			parts.append("[%s]" % label)
	map_path.text = "  ".join(parts)

	map_log.text = map_msg
	explore_label.text = "Energi eksplorasi %d/%d   |   HP %d/%d   |   Cahaya %d/%d   |   Panci %d/%d" % [
		explore_energy, EXPLORE_ENERGY, player_hp, player_max, light, MAX_LIGHT, pot.size(), MAX_POT]

	for child in explore_box.get_children():
		child.queue_free()
	for i in explore_hand.size():
		var n: String = explore_hand[i]
		var b := Button.new()
		b.custom_minimum_size = Vector2(160, 90)
		b.text = "%s\n(Energi 1)\n%s" % [n, EXPLORE_DB[n].text]
		b.disabled = explore_energy < 1
		_style_button(b, Color(0.3, 0.55, 0.85))
		_set_icon(b, n)
		b.pressed.connect(_play_explore.bind(i))
		explore_box.add_child(b)

	for child in door_box.get_children():
		child.queue_free()
	for i in doors.size():
		var d: Dictionary = doors[i]
		var b := Button.new()
		b.custom_minimum_size = Vector2(180, 90)
		if d["revealed"]:
			b.text = "%s\n%s" % [DOOR_NAMES[d["type"]], DOOR_INFO[d["type"]]]
			_style_button(b, DOOR_COLORS[d["type"]])
		else:
			b.text = "Pintu %d\n???" % (i + 1)
			_style_button(b, Color(0.5, 0.5, 0.5))
		b.pressed.connect(_choose_door.bind(i))
		door_box.add_child(b)

	_save_game()


func _play_explore(i: int) -> void:
	if explore_energy < 1:
		return
	var n: String = explore_hand[i]
	var msg := ""

	match n:
		"Intip":
			var hidden: Array = []
			for j in doors.size():
				if not doors[j]["revealed"]:
					hidden.append(j)
			if hidden.is_empty():
				map_msg = "Semua pintu sudah terbuka."
				_refresh_map()
				return
			var pick: int = hidden.pick_random()
			doors[pick]["revealed"] = true
			msg = "Kamu mengintip: Pintu %d adalah %s." % [pick + 1, DOOR_NAMES[doors[pick]["type"]]]
		"Cari":
			var reward: String = CARD_DB.keys().pick_random()
			discard.append(reward)
			msg = "Kamu menemukan kartu %s di tumpukan sampah." % reward
		"Bekal":
			player_hp = min(player_max, player_hp + 4)
			msg = "Kamu menyantap bekal. HP +4."
		"Asah":
			var candidates: Array = []
			for k in CARD_DB.keys():
				if CARD_DB[k].damage > 0:
					candidates.append(k)
			var chosen: String = candidates.pick_random()
			card_bonus[chosen] = card_bonus.get(chosen, 0) + 2
			msg = "Kamu mengasah %s. Serangannya kini +%d permanen." % [chosen, card_bonus[chosen]]
		"Obor":
			light = min(MAX_LIGHT, light + 2)
			msg = "Kamu menyalakan obor. Cahaya +2."

	explore_energy -= 1
	explore_hand.remove_at(i)
	explore_discard.append(n)
	map_msg = msg
	_refresh_map()


func _advance_floor(drain: bool = true) -> void:
	floor_i += 1
	_enter_map(drain)


func _choose_door(i: int) -> void:
	var d: Dictionary = doors[i]
	match d["type"]:
		"musuh", "boss":
			map_panel.visible = false
			battle_root.visible = true
			discard.append_array(hand)
			hand.clear()
			_spawn_enemy(floor_i)
			_start_turn(FLOORS[floor_i].intro + "\n")
		"api":
			player_hp = min(player_max, player_hp + CAMPFIRE_HEAL)
			light = MAX_LIGHT
			map_msg = "Kamu beristirahat di api unggun. HP +%d dan cahaya penuh." % CAMPFIRE_HEAL
			if not pot.is_empty():
				var n := pot.size()
				player_max += n * SOUP_MAXHP
				player_hp = min(player_max, player_hp + n * SOUP_HEAL)
				map_msg += "\nKamu memasak sup dari %d jamur! HP +%d dan HP maks +%d." % [n, n * SOUP_HEAL, n * SOUP_MAXHP]
				pot.clear()
			_advance_floor(false)
		"harta":
			var reward: String = CARD_DB.keys().pick_random()
			discard.append(reward)
			map_msg = "Peti terbuka! Kamu mendapat kartu %s." % reward
			_advance_floor()
		"jebakan":
			player_hp -= TRAP_DAMAGE
			if player_hp <= 0:
				player_hp = 0
				map_panel.visible = false
				_clear_save()
				_open_story(["Kamu terperangkap di kegelapan lorong... Kelam menelan desamu."], "Main Lagi", _reload)
				return
			map_msg = "Jebakan spora! HP -%d." % TRAP_DAMAGE
			_advance_floor()


# ---------- Battle ----------

func _current_action() -> String:
	return enemy_pattern[enemy_turn % enemy_pattern.size()]


func _action_damage(action: String) -> int:
	match action:
		"berat":
			return enemy_dmg * 2
		"racun", "gelap":
			return int(enemy_dmg / 2.0)
		"pulih":
			return 0
	return enemy_dmg


func _intent_text() -> String:
	var action := _current_action()
	var dmg := _action_damage(action)
	match action:
		"berat":
			return "SERANGAN BERAT %d!" % dmg
		"racun":
			return "serang %d + racun" % dmg
		"gelap":
			return "serang %d + padamkan cahaya" % dmg
		"pulih":
			return "memulihkan diri"
	return "serang %d" % dmg


func _refresh() -> void:
	_update_gloom()
	var intent := _intent_text()
	if battle_over:
		intent = "tumbang"
	var burn_text := ""
	if enemy_burn > 0:
		burn_text = "  [Terbakar x%d]" % enemy_burn
	var kelam_text := ""
	if player_poison > 0:
		kelam_text = "   [Racun x%d]" % player_poison
	if light <= 0 and not battle_over:
		kelam_text += "   [KELAM! -%d HP/giliran]" % KELAM_DAMAGE
	info_label.text = "Lantai %d/%d  |  HP: %d/%d  |  Energi: %d/%d  |  Cahaya: %d/%d%s\n%s: HP %d/%d (%s)%s" % [
		floor_i + 1, FLOORS.size(), player_hp, player_max, energy, MAX_ENERGY, light, MAX_LIGHT, kelam_text,
		enemy_name, enemy_hp, enemy_max, intent, burn_text]

	player_bar.max_value = player_max
	player_bar.value = player_hp
	enemy_bar.max_value = enemy_max
	enemy_bar.value = enemy_hp

	mushroom.burning = enemy_burn > 0 and not battle_over

	for child in hand_box.get_children():
		child.queue_free()

	for i in hand.size():
		var card_name: String = hand[i]
		var c: Dictionary = CARD_DB[card_name]
		var b := Button.new()
		b.custom_minimum_size = Vector2(140, 100)
		b.text = "%s\n(Energi %d)\n%s" % [card_name, c.cost, _card_text(c, card_name)]
		b.disabled = battle_over or game_over or c.cost > energy
		var accent := Color(0.75, 0.3, 0.25)
		if c.heal > 0:
			accent = Color(0.35, 0.65, 0.35)
		if c.burn > 0:
			accent = Color(0.95, 0.55, 0.15)
		if c.light > 0:
			accent = Color(1.0, 0.9, 0.3)
		_style_button(b, accent)
		_set_icon(b, card_name)
		b.pressed.connect(_play_card.bind(i))
		hand_box.add_child(b)

	end_btn.disabled = battle_over or game_over


func _card_text(c: Dictionary, card_name: String) -> String:
	var parts: Array = []
	if c.damage > 0:
		var bonus: int = card_bonus.get(card_name, 0)
		if bonus > 0:
			parts.append("Serang %d (+%d)" % [c.damage + bonus, bonus])
		else:
			parts.append("Serang %d" % c.damage)
	if c.burn > 0:
		parts.append("Bakar %d" % c.burn)
	if c.heal > 0:
		parts.append("Pulih %d" % c.heal)
	if c.light > 0:
		parts.append("Cahaya +%d" % c.light)
	return "\n".join(parts)


func _log(text: String) -> void:
	log_label.text = text


func _hit_flash() -> void:
	if hit_tween:
		hit_tween.kill()
	mushroom.modulate = Color(1, 0.4, 0.4)
	hit_tween = create_tween()
	hit_tween.tween_property(mushroom, "modulate", Color.WHITE, 0.3)


func _spawn_enemy(idx: int) -> void:
	floor_i = idx
	var data: Dictionary = FLOORS[idx]
	enemy_name = data.name
	enemy_max = data.hp
	enemy_hp = enemy_max
	enemy_dmg = data.dmg
	enemy_burn = 0
	enemy_turn = 0
	enemy_pattern = PATTERNS[idx]
	player_poison = 0
	battle_over = false
	action_btn.visible = false
	pot_btn.visible = false
	if hit_tween:
		hit_tween.kill()
	mushroom.modulate = Color.WHITE
	mushroom.cap_color = data.cap
	mushroom.s = data.scale
	mushroom.tex = _tex("res://assets/enemies/enemy_%d.png" % idx)
	_apply_floor_visuals(idx)


func _draw_card() -> void:
	if deck.is_empty():
		deck = discard.duplicate()
		discard.clear()
		deck.shuffle()
	if deck.is_empty():
		return
	hand.append(deck.pop_back())


func _start_turn(prefix: String = "") -> void:
	energy = MAX_ENERGY
	while hand.size() < HAND_SIZE:
		_draw_card()
		if deck.is_empty() and discard.is_empty():
			break
	_log(prefix + "Giliranmu! Mainkan kartu.")
	_refresh()


func _play_card(i: int) -> void:
	if battle_over or game_over:
		return
	var card_name: String = hand[i]
	var c: Dictionary = CARD_DB[card_name]
	if c.cost > energy:
		_log("Energi tidak cukup!")
		return

	energy -= c.cost
	hand.remove_at(i)
	discard.append(card_name)

	if c.damage > 0:
		var dmg: int = c.damage + int(card_bonus.get(card_name, 0))
		enemy_hp = max(0, enemy_hp - dmg)
	if c.burn > 0:
		enemy_burn += c.burn
	if c.heal > 0:
		player_hp = min(player_max, player_hp + c.heal)
	if c.light > 0:
		light = min(MAX_LIGHT, light + c.light)
	if c.damage > 0 or c.burn > 0:
		_hit_flash()
		_play_sfx("hit")
	_log("Kamu memainkan %s." % card_name)

	if enemy_hp <= 0:
		_win_battle()
	_refresh()


func _end_turn() -> void:
	if battle_over or game_over:
		return
	discard.append_array(hand)
	hand.clear()

	var msg := ""

	# 1) Efek terbakar bekerja dulu, lalu stack berkurang 1
	if enemy_burn > 0:
		enemy_hp = max(0, enemy_hp - enemy_burn)
		msg += "%s terbakar! -%d HP.\n" % [enemy_name, enemy_burn]
		enemy_burn -= 1
		_hit_flash()
		if enemy_hp <= 0:
			_win_battle()
			_refresh()
			return

	# 2) Musuh bertindak sesuai polanya
	var action := _current_action()
	var dmg := _action_damage(action)
	enemy_turn += 1
	match action:
		"pulih":
			var healed := mini(8, enemy_max - enemy_hp)
			enemy_hp += healed
			msg += "%s memulihkan diri! +%d HP.\n" % [enemy_name, healed]
		"berat":
			msg += "%s menghantam dengan SERANGAN BERAT! -%d HP.\n" % [enemy_name, dmg]
		"racun":
			player_poison += 3
			msg += "%s menyemburkan racun! -%d HP dan kamu keracunan.\n" % [enemy_name, dmg]
		"gelap":
			light = max(0, light - 1)
			msg += "%s menyelubungimu dengan bayangan! -%d HP dan cahaya padam 1.\n" % [enemy_name, dmg]
		_:
			msg += "%s menyerang! -%d HP.\n" % [enemy_name, dmg]
	player_hp -= dmg
	if player_hp <= 0:
		player_hp = 0
		_lose()
		return

	# 3) Kelam: tanpa cahaya, kegelapan menggerogotimu
	if light <= 0:
		player_hp -= KELAM_DAMAGE
		_play_sfx("kelam")
		if player_hp <= 0:
			player_hp = 0
			_lose()
			return
		msg += "Kelam menggerogotimu! -%d HP.\n" % KELAM_DAMAGE

	# 4) Racun bekerja, lalu stack berkurang 1
	if player_poison > 0:
		player_hp -= player_poison
		msg += "Racun bekerja! -%d HP.\n" % player_poison
		player_poison -= 1
		if player_hp <= 0:
			player_hp = 0
			_lose()
			return

	_start_turn(msg)


func _win_battle() -> void:
	battle_over = true
	enemy_burn = 0
	player_poison = 0
	if hit_tween:
		hit_tween.kill()
	mushroom.modulate = Color(0.5, 0.5, 0.5, 0.6)
	if floor_i >= FLOORS.size() - 1:
		action_btn.text = "Santap Jantung Kelam"
		pot_btn.visible = false
	else:
		action_btn.text = "Makan %s (+%d HP)" % [enemy_name, EAT_HEAL]
		pot_btn.text = "Masukkan ke panci (%d/%d)" % [pot.size(), MAX_POT]
		pot_btn.visible = pot.size() < MAX_POT
	action_btn.visible = true
	_log("%s kalah! Makan sekarang, atau simpan di panci untuk sup di api unggun?" % enemy_name)


func _lose() -> void:
	_clear_save()
	game_over = true
	action_btn.text = "Main Lagi"
	action_btn.visible = true
	pot_btn.visible = false
	_log("Kamu kalah... Kelam menelan desamu.")
	_refresh()


func _after_battle(base_msg: String) -> void:
	var reward: String = CARD_DB.keys().pick_random()
	discard.append(reward)
	discard.append_array(hand)
	hand.clear()
	floor_i += 1
	map_msg = "%s Kamu juga mendapat kartu %s." % [base_msg, reward]
	_enter_map()


func _on_action_pressed() -> void:
	if game_over:
		_reload()
		return

	# Boss kalah -> cerita penutup
	if floor_i >= FLOORS.size() - 1:
		_show_ending()
		return

	# Makan musuh langsung: pulihkan HP
	player_hp = min(player_max, player_hp + EAT_HEAL)
	_play_sfx("eat")
	_after_battle("Nyam! HP +%d." % EAT_HEAL)


func _on_pot_pressed() -> void:
	if pot.size() >= MAX_POT:
		return
	pot.append(enemy_name)
	_after_battle("%s masuk ke panci (%d/%d). Masaklah di api unggun." % [enemy_name, pot.size(), MAX_POT])


# ---------- Menu utama, jeda, simpan ----------

func _make_menu_button(text: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(240, 48)
	b.pressed.connect(callback)
	return b


func _build_menu_panel() -> void:
	menu_panel = ColorRect.new()
	menu_panel.color = Color(0.04, 0.03, 0.05)
	add_child(menu_panel)
	menu_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	menu_panel.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	center.add_child(box)

	var title := _make_label(56, Color(0.95, 0.55, 0.15))
	title.text = "SPORA & KELAM"
	box.add_child(title)

	var sub := _make_label(18, Color(0.8, 0.75, 0.7))
	sub.text = "Koki terakhir Desa Lumut melawan kegelapan"
	box.add_child(sub)

	box.add_child(_make_menu_button("Mulai Baru", _new_game))
	continue_btn = _make_menu_button("Lanjutkan", _load_game)
	box.add_child(continue_btn)
	box.add_child(_make_menu_button("Keluar", _quit))


func _build_pause_ui() -> void:
	pause_btn = Button.new()
	pause_btn.text = "Jeda"
	pause_btn.visible = false
	pause_btn.pressed.connect(_toggle_pause)
	add_child(pause_btn)
	pause_btn.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 12)

	pause_panel = ColorRect.new()
	pause_panel.color = Color(0, 0, 0, 0.75)
	pause_panel.visible = false
	add_child(pause_panel)
	pause_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	pause_panel.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	center.add_child(box)

	var title := _make_label(36, Color(0.95, 0.55, 0.15))
	title.text = "JEDA"
	box.add_child(title)

	var vol_label := _make_label(18)
	vol_label.text = "Volume"
	box.add_child(vol_label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = 1.0
	slider.custom_minimum_size = Vector2(240, 24)
	slider.value_changed.connect(_on_volume_changed)
	box.add_child(slider)

	box.add_child(_make_menu_button("Lanjut Main", _toggle_pause))
	box.add_child(_make_menu_button("Menu Utama", _reload))
	box.add_child(_make_menu_button("Keluar", _quit))


func _toggle_pause() -> void:
	pause_panel.visible = not pause_panel.visible


func _on_volume_changed(v: float) -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(v, 0.001)))


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and pause_btn.visible:
		_toggle_pause()


func _quit() -> void:
	get_tree().quit()


func _new_game() -> void:
	_clear_save()
	menu_panel.visible = false
	_open_story(STORY_INTRO, "Mulai", _begin_game)


func _save_game() -> void:
	var all_cards: Array = []
	all_cards.append_array(deck)
	all_cards.append_array(hand)
	all_cards.append_array(discard)
	var data := {
		"floor_i": floor_i,
		"hp": player_hp,
		"max": player_max,
		"light": light,
		"pot": pot,
		"cards": all_cards,
		"bonus": card_bonus,
		"doors": doors,
		"explore_hand": explore_hand,
		"explore_deck": explore_deck,
		"explore_discard": explore_discard,
		"explore_energy": explore_energy,
		"map_msg": map_msg,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
		f.close()


func _clear_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(SAVE_PATH)


func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var d: Dictionary = parsed

	floor_i = int(d.get("floor_i", 0))
	player_hp = int(d.get("hp", 30))
	player_max = int(d.get("max", 30))
	light = int(d.get("light", 3))
	pot = d.get("pot", [])
	deck = d.get("cards", START_DECK.duplicate())
	deck.shuffle()
	hand.clear()
	discard.clear()
	card_bonus.clear()
	var bonus: Dictionary = d.get("bonus", {})
	for k in bonus.keys():
		card_bonus[k] = int(bonus[k])
	explore_hand = d.get("explore_hand", [])
	explore_deck = d.get("explore_deck", [])
	explore_discard = d.get("explore_discard", [])
	explore_energy = int(d.get("explore_energy", EXPLORE_ENERGY))
	doors = d.get("doors", [])
	if doors.is_empty():
		doors = _make_doors()
	map_msg = d.get("map_msg", "")

	menu_panel.visible = false
	story_panel.visible = false
	game_over = false
	battle_over = false
	_show_map()
